﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login
{
    internal class Cliente: Persona
    {
        public Cliente() { }

        public Cliente(int identificacion, string nombre, string direccion, string correo, int pago): base(nombre, direccion, correo) { 
        
            Identificacion= identificacion;
            Nombre = nombre;
            Direccion= direccion;
            Correo= correo;
            Pago= pago;

        }

        public int Identificacion { get; set; }
        public int Pago { get; set; }

        //public List<Pedido> HistorialDeCompra { get; set; } //Se utilizara la clase pedido para el historial de compra

    }
}
