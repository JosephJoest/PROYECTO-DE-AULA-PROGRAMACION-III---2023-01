﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login
{
    internal class Administrador: Persona
    {
        public Administrador() { }  

        public Administrador(string nombreusuario, string nombre, string direccion, string correo): base(nombre, direccion, correo) { }  

       
        //public List<CRUD> Facultades { get; set; } //Facultades de crear, modificar y eliminar


    }
}
