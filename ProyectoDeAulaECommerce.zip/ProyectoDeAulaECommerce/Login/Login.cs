﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login
{
    public class Login
    {

        public Login() { }  

        public Login(string username, string password) {
        
            Usuario = username;
            Contraseña= password;

        }

        public int Id { get; set; } 
        public string Usuario { get; set; }
        public string Contraseña { get; set; }
        public char TipoUsuario { get; set; } //Tipos de usuarios: Cliente = 1, Administrador = 2

        public string Validar { get; set; } //Esto valida si el usurio tiene acceso 



    }
}
