﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login
{
    internal class Persona
    {

        public Persona() { }

        public Persona(string name, string addres, string correo) { 
            Nombre = name;
            Direccion = addres;
            Correo = correo;
        }

        public string Nombre { get; set; }  
        public string Direccion { get; set; }
        public string Correo { get; set; }



    }
}
