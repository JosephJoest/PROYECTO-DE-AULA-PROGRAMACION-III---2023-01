﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Producto
{
    public class Producto
    {
        public Producto() { }

        public Producto(int id, string nombreproducto, string categoriaproducto, string descripcion, int precio, int cantidadinventario) {
            IdProducto= id;
            NombreProducto= nombreproducto;
            CategoriaProducto= categoriaproducto;
            Descripcion= descripcion;
            Precio= precio;
            CantidadInventario= cantidadinventario;
        }    


        public int IdProducto { get; set; } 

        public string NombreProducto { get; set; }

        public string CategoriaProducto { get; set; }

        public string Descripcion { get; set; } 

        public int Precio { get; set; } 

        public int CantidadInventario { get; set; }

    }
}
