﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pedido
{
    internal class Envio
    {
        public Envio() { }  

        public Envio(int id, bool pagorecibido, string direccionenvio, bool enviado, bool recibido) {
            IdEnvio = id;
            PagoRecibido= pagorecibido;
            DireccionEnvio= direccionenvio;
            Enviado= enviado;
            Recibido= recibido;
        }

        public int IdEnvio { get; set; }

        public bool PagoRecibido { get; set; }

        public string DireccionEnvio { get; set; }

        public bool Enviado { get; set; }

        public bool Recibido { get; set; }  




    }
}
