﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pedido
{
    public class Pedido
    {

        public Pedido() { }

        public Pedido(int idpedido, string informacioncliente, string productoseleccionado, string preciototal, DateTime fechaenvio) {
            
            IdPedido= idpedido;
            InformacionCliente= informacioncliente;
            ProductoSeleccionado= productoseleccionado;
            PrecioTotal= preciototal;
            FechaEnvio= fechaenvio;
        
        }


        public int IdPedido { get; set; }

        public string InformacionCliente { get; set;}

        public string ProductoSeleccionado { get; set;}  

        public string PrecioTotal { get; set;}

        public DateTime FechaEnvio { get; set;}

    }
}
