﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pedido
{
    internal class Pago
    {
        public Pago() { }

        public Pago(int id, string metodopago, string numerotarjeta, bool pago) {
            IdPago= id;
            MetodoPago= metodopago;
            Numerotarjeta= numerotarjeta;
            PagoC= pago;
        
        }

        public int IdPago { get; set; }

        public string MetodoPago { get; set; }

        public string Numerotarjeta { get; set; }

        public bool PagoC { get; set; } //true or false



    }
}
