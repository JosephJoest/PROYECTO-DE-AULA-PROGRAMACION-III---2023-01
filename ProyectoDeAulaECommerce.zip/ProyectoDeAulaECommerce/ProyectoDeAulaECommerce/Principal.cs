﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoDeAulaECommerce
{
    internal class Principal
    {
        static void Main(string[] args)
        {





        }
    }
}
